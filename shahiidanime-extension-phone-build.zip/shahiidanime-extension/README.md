# Shahiid Anime extension for Mihon/Tachiyomi

هذه حزمة كود لإضافة Mihon/Tachiyomi باسم **Shahiid Anime**.

> مهم: هذا الملف المضغوط ليس APK جاهزًا للتثبيت. يجب بناؤه أولًا. أسهل طريقة من الهاتف فقط هي GitHub Actions.

## البناء من الهاتف فقط عبر GitHub Actions

1. فك ضغط الملف على هاتفك باستخدام تطبيق ملفات أو ZArchiver.
2. افتح GitHub من المتصفح وسجّل الدخول.
3. أنشئ Repository جديدًا، مثل: `shahiidanime-extension`.
4. افتح المستودع من المتصفح واضغط `Add file` ثم `Upload files`.
5. ارفع محتويات المجلد بعد فك الضغط، وليس ملف zip نفسه. يجب أن تظهر هذه المسارات في GitHub:
   - `.github/workflows/build-shahiidanime.yml`
   - `src/ar/shahiidanime/build.gradle`
   - `src/ar/shahiidanime/src/eu/kanade/tachiyomi/extension/ar/shahiidanime/ShahiidAnime.kt`
6. اضغط `Commit changes`.
7. افتح تبويب `Actions` في GitHub.
8. اختر `Build Shahiid Anime APK`.
9. اضغط `Run workflow` إن لم يبدأ تلقائيًا.
10. بعد انتهاء البناء بنجاح، افتح آخر Run، ثم من قسم `Artifacts` حمّل `shahiidanime-debug-apk`.
11. فك ضغط artifact، وستجد ملف APK داخله.
12. ثبّت APK على Android، ثم افتح Mihon وفعّل/ثق بالإضافة إذا طلب ذلك.

## البناء داخل Keiyoushi extensions-source، لمن لديه كمبيوتر

انسخ هذا المسار داخل جذر مستودع Keiyoushi `extensions-source`:

```text
src/ar/shahiidanime/
```

ثم شغّل:

```bash
./gradlew src:ar:shahiidanime:assembleDebug
```

سيظهر APK هنا غالبًا:

```text
src/ar/shahiidanime/build/outputs/apk/debug/
```

## Scope / حدود الإضافة

الموقع `https://shahiid-anime.net` موقع أنمي/فيديو وليس موقع مانجا صور. لذلك الإضافة لا تستخرج روابط فيديو أو iframes أو روابط تحميل أو محتوى محمي. تعرض الكتالوج، البحث، التفاصيل، وروابط الحلقات كفصول، وتعرض الصور العامة فقط داخل القارئ.

لا تستخدم هذه الإضافة لتجاوز تسجيل الدخول، paywalls، DRM، CAPTCHA، Cloudflare، أو أي قيود وصول.
