package eu.kanade.tachiyomi.extension.ar.shahiidanime

import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import eu.kanade.tachiyomi.util.asJsoup
import okhttp3.Headers
import okhttp3.Request
import okhttp3.Response
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import java.util.Locale

class ShahiidAnime : HttpSource() {

    override val name = "Shahiid Anime"

    override val baseUrl = "https://shahiid-anime.net"

    override val lang = "ar"

    override val supportsLatest = true

    override val headers: Headers = headersBuilder()
        .add("Accept-Language", "ar,en-US;q=0.8,en;q=0.5")
        .build()

    override fun popularMangaRequest(page: Int): Request =
        GET(archiveUrl("series", page), headers)

    override fun popularMangaParse(response: Response): MangasPage =
        parseCatalog(response.asJsoup(), listOf("/series/"), "series")

    override fun latestUpdatesRequest(page: Int): Request =
        GET(archiveUrl("episodes", page), headers)

    override fun latestUpdatesParse(response: Response): MangasPage =
        parseCatalog(response.asJsoup(), listOf("/episodes/"), "episodes")

    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val pageParam = if (page > 1) "&paged=$page" else ""
        return GET("$baseUrl/?s=$encoded$pageParam", headers)
    }

    override fun searchMangaParse(response: Response): MangasPage =
        parseCatalog(
            response.asJsoup(),
            listOf("/series/", "/seasons/", "/episodes/"),
            null,
        )

    override fun mangaDetailsParse(response: Response): SManga {
        val document = response.asJsoup()
        val bodyText = document.body()?.text().orEmpty()
        val description = extractDescription(bodyText)
        val limitationNote = "ملاحظة: Shahiid Anime يعرض حلقات فيديو، بينما Mihon قارئ صور. هذا الامتداد لا يستخرج روابط بث أو تحميل."

        return SManga.create().apply {
            title = document.selectFirst("h1")?.text()?.let(::cleanTitle).orEmpty()
            thumbnail_url = document.metaImage() ?: document.firstUsableImage()
            genre = extractGenres(bodyText).joinToString(", ")
            author = extractLabel(bodyText, "الاستوديو:", listOf("الجودة", "الفئة العمرية", "السنة", "النوع", "رقم"))
            artist = extractLabel(bodyText, "الدولة :", listOf("اللغة", "حالة", "مدة", "تقييم"))
            status = parseStatus(bodyText)
            this.description = listOf(description, limitationNote)
                .filter { it.isNotBlank() }
                .joinToString("\n\n")
        }
    }

    override fun chapterListParse(response: Response): List<SChapter> {
        val document = response.asJsoup()
        val chapters = linkedMapOf<String, SChapter>()

        parseEpisodeChapters(document).forEach { chapter ->
            chapters[chapter.url] = chapter
        }

        if (chapters.isEmpty()) {
            parseSeasonLinks(document).forEach { seasonUrl ->
                runCatching { fetchDocument(seasonUrl) }
                    .getOrNull()
                    ?.let(::parseEpisodeChapters)
                    ?.forEach { chapter -> chapters[chapter.url] = chapter }
            }
        }

        if (chapters.isEmpty() && document.location().contains("/episodes/")) {
            val requestUrl = response.request.url.toString()
            val episodeTitle = document.selectFirst("h1")?.text()?.let(::cleanTitle)
                ?: "مشاهدة الحلقة"
            chapters[requestUrl.toRelativeUrl()] = SChapter.create().apply {
                name = episodeTitle
                url = requestUrl.toRelativeUrl()
                chapter_number = parseEpisodeNumber(episodeTitle)
            }
        }

        return chapters.values
            .sortedWith(
                compareByDescending<SChapter> { chapter ->
                    chapter.chapter_number.takeIf { it >= 0F } ?: -1F
                }.thenByDescending { it.url },
            )
    }

    override fun pageListParse(response: Response): List<Page> {
        val document = response.asJsoup()
        val imageUrls = linkedSetOf<String>()

        document.select("meta[property=og:image], meta[name=twitter:image]")
            .mapNotNullTo(imageUrls) { it.imageUrl() }

        document.select("article img, main img, .post img, .content img, .poster img, img")
            .mapNotNullTo(imageUrls) { it.imageUrl() }

        // Intentionally do not parse video players, download buttons, iframe embeds, or host-specific stream URLs.
        return imageUrls
            .filter(::isUsableImage)
            .mapIndexed { index, imageUrl -> Page(index = index, imageUrl = imageUrl) }
    }

    override fun imageRequest(page: Page): Request =
        GET(page.imageUrl!!, headers.newBuilder().set("Referer", baseUrl).build())

    override fun imageUrlParse(response: Response): String =
        throw UnsupportedOperationException("Image URLs are supplied directly by pageListParse")

    override fun getFilterList(): FilterList = FilterList()

    private fun archiveUrl(path: String, page: Int): String =
        if (page <= 1) "$baseUrl/$path/" else "$baseUrl/$path/page/$page/"

    private fun parseCatalog(document: Document, allowedSegments: List<String>, archivePath: String?): MangasPage {
        val entries = linkedMapOf<String, SManga>()

        document.select("a[href]").forEach { anchor ->
            val href = anchor.absUrl("href")
            if (href.isBlank()) return@forEach

            val relative = href.toRelativeUrl()
            if (allowedSegments.none { relative.contains(it) }) return@forEach
            if (isNavigationUrl(relative)) return@forEach

            val rawTitle = anchor.text()
                .ifBlank { anchor.attr("title") }
                .ifBlank { anchor.selectFirst("img")?.attr("alt").orEmpty() }
            val title = cleanTitle(rawTitle)
            if (title.isBlank() || looksLikeNavigationTitle(title)) return@forEach

            val manga = SManga.create().apply {
                this.title = title
                url = relative
                thumbnail_url = findNearbyImage(anchor)
            }

            val existing = entries[relative]
            if (existing == null || titleScore(manga.title) > titleScore(existing.title)) {
                entries[relative] = manga
            }
        }

        return MangasPage(entries.values.toList(), hasNextPage(document, archivePath))
    }

    private fun parseEpisodeChapters(document: Document): List<SChapter> {
        val chapters = linkedMapOf<String, SChapter>()

        document.select("a[href*='/episodes/']").forEach { anchor ->
            val href = anchor.absUrl("href")
            if (href.isBlank()) return@forEach

            val relative = href.toRelativeUrl()
            if (isNavigationUrl(relative)) return@forEach

            val rawName = anchor.text()
                .ifBlank { anchor.attr("title") }
                .ifBlank { anchor.selectFirst("img")?.attr("alt").orEmpty() }
            val name = cleanTitle(rawName)
            if (name.isBlank() || looksLikeNavigationTitle(name)) return@forEach

            val chapter = SChapter.create().apply {
                this.name = name
                url = relative
                chapter_number = parseEpisodeNumber(name)
            }

            val existing = chapters[relative]
            if (existing == null || titleScore(chapter.name) > titleScore(existing.name)) {
                chapters[relative] = chapter
            }
        }

        return chapters.values.toList()
    }

    private fun parseSeasonLinks(document: Document): List<String> = document
        .select("a[href*='/seasons/']")
        .map { it.absUrl("href") }
        .filter { it.isNotBlank() }
        .filterNot { it.toRelativeUrl() == document.location().toRelativeUrl() }
        .distinct()

    private fun fetchDocument(url: String): Document =
        client.newCall(GET(url, headers)).execute().use { it.asJsoup() }

    private fun hasNextPage(document: Document, archivePath: String?): Boolean {
        val nextByRel = document.select("a[rel=next]").isNotEmpty()
        if (nextByRel) return true

        return document.select("a[href]").any { anchor ->
            val href = anchor.absUrl("href")
            val text = anchor.text().trim()
            val pointsToNextArchive = archivePath == null || href.contains("/$archivePath/page/") || href.contains("paged=")
            pointsToNextArchive && (text == "›" || text == "»" || text.equals("next", ignoreCase = true))
        }
    }

    private fun Document.metaImage(): String? = selectFirst("meta[property=og:image], meta[name=twitter:image]")
        ?.imageUrl()
        ?.takeIf(::isUsableImage)

    private fun Document.firstUsableImage(): String? = select("img")
        .asSequence()
        .mapNotNull { it.imageUrl() }
        .firstOrNull(::isUsableImage)

    private fun findNearbyImage(element: Element): String? =
        (sequenceOf(element) + element.parents().asSequence().take(3))
            .flatMap { it.select("img").asSequence() }
            .mapNotNull { it.imageUrl() }
            .firstOrNull(::isUsableImage)

    private fun Element.imageUrl(): String? {
        val attrs = when (tagName().lowercase(Locale.ROOT)) {
            "meta" -> listOf("content")
            else -> listOf("data-src", "data-lazy-src", "data-original", "src")
        }

        attrs.forEach { attrName ->
            val raw = attr(attrName).trim()
            if (raw.isBlank() || raw.startsWith("data:")) return@forEach
            if (raw.startsWith("//")) return "https:$raw"
            if (raw.startsWith("http://") || raw.startsWith("https://")) return raw

            val absolute = absUrl(attrName)
            if (absolute.isNotBlank()) return absolute
            return "$baseUrl/${raw.removePrefix("/")}"
        }

        return null
    }

    private fun String.toRelativeUrl(): String = replace(Regex("^https?://(www\\.)?shahiid-anime\\.net"), "")
        .ifBlank { "/" }

    private fun isNavigationUrl(relativeUrl: String): Boolean =
        relativeUrl == "/" ||
            relativeUrl == "/series/" ||
            relativeUrl == "/episodes/" ||
            relativeUrl.contains("/page/") ||
            relativeUrl.contains("#") ||
            relativeUrl.contains("?download=") ||
            relativeUrl.contains("/privacy") ||
            relativeUrl.contains("/dmca")

    private fun looksLikeNavigationTitle(title: String): Boolean {
        val normalized = title.trim().lowercase(Locale.ROOT)
        if (normalized.isBlank()) return true
        if (normalized.matches(Regex("^[0-9.]+$"))) return true
        if (normalized in setOf("الرئيسية", "قائمة الأنمي", "تصفح المزيد", "تصفح المزيد ...", "تحميل الحلقة", "مشاهدة الحلقة", "تبليغ", "privacy", "dmca")) return true
        return normalized.length <= 1
    }

    private fun cleanTitle(rawTitle: String): String {
        var title = rawTitle
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()

        title = title.replace(Regex("^(TV|ONA|OVA|Movie|Web|Bluray|BD|FHD|HD|مدبلج)\\s+", RegexOption.IGNORE_CASE), "")
        title = title.replace(Regex("^\\d(?:\\.\\d{1,2})?\\s+"), "")

        return title.trim(' ', '-', '–', '|')
    }

    private fun titleScore(title: String): Int = title.length + if (title.contains("الحلقة")) 20 else 0

    private fun parseEpisodeNumber(name: String): Float {
        val patterns = listOf(
            Regex("الحلقة\\s*(?:الخاصة\\s*)?(\\d+(?:\\.\\d+)?)"),
            Regex("episode\\s*(\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE),
            Regex("ep[-_\\s]*(\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE),
        )

        return patterns.firstNotNullOfOrNull { regex ->
            regex.find(name)?.groupValues?.getOrNull(1)?.toFloatOrNull()
        } ?: -1F
    }

    private fun parseStatus(text: String): Int = when {
        text.contains("يعرض حاليا") || text.contains("مستمر") || text.contains("أنميات المستمرة") -> SManga.ONGOING
        text.contains("مكتمل") || text.contains("منتهي") || text.contains("الأخيرة") -> SManga.COMPLETED
        else -> SManga.UNKNOWN
    }

    private fun extractDescription(text: String): String {
        val startMarkers = listOf("قصة الأنيمي :", "قصة الأنيمي:", "قصة هذا الموسم:", "قصة الحلقة :", "قصة الحلقة:")
        val endMarkers = listOf("الاستوديو:", "الجودة :", "الجودة:", "الفئة العمرية", "السنة :", "النوع :", "رقم المسلسل", "رقم الموسم", "رقم الحلقة", "الرابط المختصر")

        val start = startMarkers
            .map { text.indexOf(it) }
            .filter { it >= 0 }
            .minOrNull()
            ?: return ""

        val afterStart = startMarkers.firstOrNull { text.indexOf(it) == start }
            ?.let { start + it.length }
            ?: start

        val end = endMarkers
            .map { text.indexOf(it, afterStart) }
            .filter { it > afterStart }
            .minOrNull()
            ?: text.length

        return text.substring(afterStart, end)
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun extractLabel(text: String, startMarker: String, endMarkers: List<String>): String? {
        val start = text.indexOf(startMarker)
        if (start < 0) return null
        val afterStart = start + startMarker.length
        val end = endMarkers
            .map { text.indexOf(it, afterStart) }
            .filter { it > afterStart }
            .minOrNull()
            ?: text.length

        return text.substring(afterStart, end)
            .replace(Regex("\\s+"), " ")
            .trim(' ', ':', '،', ',')
            .takeIf { it.isNotBlank() }
    }

    private fun extractGenres(text: String): List<String> = knownGenres.filter { genre ->
        Regex("(^|\\s|،|,)$genre(\\s|،|,|$)").containsMatchIn(text)
    }

    private fun isUsableImage(url: String): Boolean {
        val normalized = url.lowercase(Locale.ROOT)
        if (normalized.isBlank()) return false
        if ("shahiid-anime" in normalized && ("logo" in normalized || "220px" in normalized)) return false
        return normalized.startsWith("http://") || normalized.startsWith("https://")
    }

    private val knownGenres = listOf(
        "أساطير",
        "أطفال",
        "أكشن",
        "أيدول",
        "إيسكاي",
        "اتشي",
        "الاثارة",
        "التاريخية",
        "الجيش",
        "الرياضة",
        "الساموراي",
        "الشرطة",
        "الفضاء",
        "القصة المثيرة",
        "المغامرة",
        "النفسي",
        "ايتشي",
        "بقاء",
        "تاريخي",
        "تاريخية",
        "تحقيق",
        "تشويق",
        "جريمة",
        "جوسي",
        "حب بنات",
        "حركة",
        "حريم",
        "حياة عملية",
        "خارق",
        "خارق للطبيعة",
        "خيال",
        "خيال علمي",
        "دراما",
        "ذواقة",
        "رعب",
        "رومانسي",
        "رياضة",
        "رياضي",
        "ساخر",
        "ساموراي",
        "سباق",
        "سحر",
        "سنين",
        "سوجو",
        "سينين",
        "شريحة من الحياة",
        "شوتينغ",
        "شوجو",
        "شونين",
        "شياطين",
        "شيطان",
        "عاطفي",
        "عسكري",
        "علمي",
        "عنف دموي",
        "غموض",
        "فانتازيا",
        "فضاء",
        "فنون الدفاع عن النفس",
        "فنون القتال",
        "قوة",
        "قوة عظمى",
        "قوى خارقة",
        "كوميديا",
        "لعبة",
        "مدبلج",
        "مدرسي",
        "مشاغبون",
        "مصاص الدماء",
        "مغامرات",
        "موسيقى",
        "ميكا",
        "نفسي",
    )
}
