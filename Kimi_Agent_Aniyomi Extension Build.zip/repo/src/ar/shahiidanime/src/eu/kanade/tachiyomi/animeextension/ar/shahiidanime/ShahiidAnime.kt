package eu.kanade.tachiyomi.animeextension.ar.shahiidanime

import android.app.Application
import android.content.SharedPreferences
import android.util.Log
import androidx.preference.ListPreference
import androidx.preference.PreferenceScreen
import eu.kanade.tachiyomi.animesource.ConfigurableAnimeSource
import eu.kanade.tachiyomi.animesource.model.AnimeFilterList
import eu.kanade.tachiyomi.animesource.model.AnimesPage
import eu.kanade.tachiyomi.animesource.model.SAnime
import eu.kanade.tachiyomi.animesource.model.SEpisode
import eu.kanade.tachiyomi.animesource.model.Video
import eu.kanade.tachiyomi.animesource.online.AnimeHttpSource
import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.network.POST
import eu.kanade.tachiyomi.util.asJsoup
import kotlinx.serialization.json.Json
import okhttp3.FormBody
import okhttp3.Request
import okhttp3.Response
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import uy.kohesive.injekt.injectLazy
import java.lang.Exception

class ShahiidAnime : ConfigurableAnimeSource, AnimeHttpSource() {

    override val name = "Shahiid Anime"

    override val baseUrl = "https://shahiid-anime.net"

    override val lang = "ar"

    override val supportsLatest = true

    private val json: Json by injectLazy()

    private val preferences: SharedPreferences by lazy {
        Injekt.get<Application>().getSharedPreferences("source_$id", 0x0000)
    }

    // ============================== Popular ===============================

    override fun popularAnimeRequest(page: Int): Request {
        return GET("$baseUrl/series/page/$page/", headers)
    }

    override fun popularAnimeParse(response: Response): AnimesPage {
        val document = response.asJsoup()
        val animeList = document.select("div.one-poster")
            .map { element ->
                SAnime.create().apply {
                    val link = element.selectFirst("h2 a") ?: element.selectFirst("a")!!
                    setUrlWithoutDomain(link.attr("href"))
                    title = link.attr("title").ifBlank {
                        link.text().trim()
                    }.ifBlank {
                        element.selectFirst("img")?.attr("alt") ?: ""
                    }
                    thumbnail_url = element.selectFirst("img")?.let {
                        it.attr("data-src").ifBlank { it.attr("src") }
                    }
                }
            }

        val hasNextPage = document.select("div.pagination a.next").isNotEmpty() ||
            document.select("div.pagination a:contains(›)").isNotEmpty()

        return AnimesPage(animeList, hasNextPage)
    }

    // ============================== Latest ===============================

    override fun latestUpdatesRequest(page: Int): Request {
        return GET("$baseUrl/episodes/page/$page/", headers)
    }

    override fun latestUpdatesParse(response: Response): AnimesPage {
        val document = response.asJsoup()
        val episodeList = document.select("div.one-poster")

        // Group episodes by series to avoid duplicates
        val seenUrls = mutableSetOf<String>()
        val animeList = mutableListOf<SAnime>()

        for (element in episodeList) {
            val episodeUrl = element.selectFirst("a")?.attr("href") ?: continue
            // Extract series URL from episode URL
            // Episode URLs like: /episodes/karna-the-guardian-ep-1/
            // We want to link to the season page: /seasons/karna-the-guardian/
            val seriesSlug = episodeUrl
                .removePrefix("/episodes/")
                .removeSuffix("/")
                .replace(Regex("-ep-\\d+$"), "")
                .replace(Regex("-%d8%a7%d9%84%d8%ad%d9%84%d9%82%d8%a9-\\d+.*$"), "")

            if (seriesSlug.isBlank()) continue

            val seasonUrl = "/seasons/$seriesSlug/"
            if (seenUrls.add(seasonUrl)) {
                val titleLink = element.selectFirst("h2 a") ?: element.selectFirst("a")!!
                animeList.add(
                    SAnime.create().apply {
                        setUrlWithoutDomain(seasonUrl)
                        title = titleLink.attr("title").ifBlank {
                            titleLink.text().trim()
                        }.ifBlank {
                            element.selectFirst("img")?.attr("alt") ?: ""
                        }
                        thumbnail_url = element.selectFirst("img")?.let {
                            it.attr("data-src").ifBlank { it.attr("src") }
                        }
                    }
                )
            }
        }

        val hasNextPage = document.select("div.pagination a.next").isNotEmpty() ||
            document.select("div.pagination a:contains(›)").isNotEmpty()

        return AnimesPage(animeList, hasNextPage)
    }

    // ============================== Search ===============================

    override fun searchAnimeRequest(page: Int, query: String, filters: AnimeFilterList): Request {
        return GET("$baseUrl/?s=$query&paged=$page", headers)
    }

    override fun searchAnimeParse(response: Response): AnimesPage {
        val document = response.asJsoup()

        // Search results may include series, seasons, and episodes
        // We prioritize series pages
        val results = document.select("article, div.one-poster, div.search-result")

        if (results.isNotEmpty()) {
            val animeList = results.mapNotNull { element ->
                val link = element.selectFirst("a[href*=/series/], a[href*=/seasons/]")
                    ?: return@mapNotNull null
                SAnime.create().apply {
                    setUrlWithoutDomain(link.attr("href"))
                    title = link.attr("title").ifBlank {
                        link.text().trim()
                    }.ifBlank {
                        element.selectFirst("img")?.attr("alt") ?: ""
                    }
                    thumbnail_url = element.selectFirst("img")?.let {
                        it.attr("data-src").ifBlank { it.attr("src") }
                    }
                }
            }.distinctBy { it.url }

            val hasNextPage = document.select("div.pagination a.next").isNotEmpty() ||
                document.select("div.pagination a:contains(›)").isNotEmpty() ||
                document.select("a:contains(التالي)").isNotEmpty()

            return AnimesPage(animeList, hasNextPage)
        }

        // Fallback: try to find any relevant links
        val fallbackLinks = document.select("a[href*=/series/], a[href*=/seasons/]")
        val animeList = fallbackLinks.map { link ->
            SAnime.create().apply {
                setUrlWithoutDomain(link.attr("href"))
                title = link.attr("title").ifBlank {
                    link.text().trim()
                }.ifBlank {
                    link.selectFirst("img")?.attr("alt") ?: ""
                }
            }
        }.distinctBy { it.url }

        return AnimesPage(animeList, false)
    }

    // ============================== Anime Details ===============================

    override fun animeDetailsParse(response: Response): SAnime {
        val document = response.asJsoup()

        return SAnime.create().apply {
            // Title
            title = document.selectFirst("h1.title, h1.entry-title, div.title h1")?.text()
                ?: document.selectFirst("title")?.text() ?: ""

            // Description
            description = document.selectFirst("div.description, div.story, div.entry-content p, div[itemprop=description]")?.text()
                ?: document.select("p").find { it.text().contains("قصة") || it.text().contains("مشاهدة") }?.text()

            // Thumbnail
            thumbnail_url = document.selectFirst("div.poster img, img.poster, div.thumb img")?.let {
                it.attr("data-src").ifBlank { it.attr("src") }
            }

            // Genre
            genre = document.select("a[href*=/series-cats/], a[href*=/genre/]")
                .map { it.text() }
                .joinToString(", ")

            // Status
            val statusText = document.selectFirst("div.status, span.status, div:contains(حالة)")?.text() ?: ""
            status = when {
                statusText.contains("مستمر") -> SAnime.ONGOING
                statusText.contains("منتهي") || statusText.contains("مكتمل") -> SAnime.COMPLETED
                else -> SAnime.UNKNOWN
            }

            // Additional info
            val typeText = document.selectFirst("a[href*=/content-type/]")?.text()
            val yearText = document.selectFirst("a[href*=/series_years/]")?.text()
            val ratingText = document.selectFirst("span.score, div.rating, div.score")?.text()

            val infoList = mutableListOf<String>()
            if (!typeText.isNullOrBlank()) infoList.add("Type: $typeText")
            if (!yearText.isNullOrBlank()) infoList.add("Year: $yearText")
            if (!ratingText.isNullOrBlank()) infoList.add("Rating: $ratingText")

            if (infoList.isNotEmpty()) {
                description = (description ?: "") + "\n\n" + infoList.joinToString("\n")
            }
        }
    }

    // ============================== Episodes ===============================

    override fun episodeListParse(response: Response): List<SEpisode> {
        val document = response.asJsoup()
        val episodes = mutableListOf<SEpisode>()

        // Episode links on season page
        val episodeLinks = document.select("nav.navbar-dark a[href*=/episodes/], div.eplist a[href*=/episodes/], a[href*=/episodes/]")

        for (link in episodeLinks) {
            val epUrl = link.attr("href")
            if (!epUrl.contains("/episodes/")) continue

            // Skip duplicate links (like "مشاهدة الحلقة" / "تحميل الحلقة")
            if (episodes.any { it.url == epUrl }) continue

            val epName = link.text().trim()
            if (epName.isBlank() || epName == "مشاهدة الحلقة" || epName == "تحميل الحلقة") continue

            // Extract episode number from URL or title
            val epNumber = extractEpisodeNumber(epName, epUrl)

            episodes.add(
                SEpisode.create().apply {
                    setUrlWithoutDomain(epUrl)
                    name = epName
                    episode_number = epNumber
                    date_upload = System.currentTimeMillis() // No date info available
                }
            )
        }

        return episodes.sortedBy { it.episode_number }
    }

    private fun extractEpisodeNumber(epName: String, epUrl: String): Float {
        // Try to extract episode number from Arabic title pattern
        val arabicPattern = Regex("الحلقة\\s+(\\d+)")
        val arabicMatch = arabicPattern.find(epName)
        if (arabicMatch != null) {
            return arabicMatch.groupValues[1].toFloatOrNull() ?: 0f
        }

        // Try English pattern like "ep-1" or "episode-1"
        val englishPattern = Regex("(?:ep|episode)[-_](\\d+)", RegexOption.IGNORE_CASE)
        val englishMatch = englishPattern.find(epUrl)
        if (englishMatch != null) {
            return englishMatch.groupValues[1].toFloatOrNull() ?: 0f
        }

        // Try any number at the end
        val numberPattern = Regex("(\\d+)(?:\\s*مترجم.*)?$")
        val numberMatch = numberPattern.find(epName)
        if (numberMatch != null) {
            return numberMatch.groupValues[1].toFloatOrNull() ?: 0f
        }

        return 0f
    }

    // ============================== Video Links ===============================

    override fun videoListParse(response: Response): List<Video> {
        val document = response.asJsoup()
        val videoList = mutableListOf<Video>()

        // Find server tabs with data-frameserver and data-post attributes
        val serverTabs = document.select("a[data-frameserver]")

        if (serverTabs.isEmpty()) {
            // Fallback: try to find iframe directly
            val iframe = document.selectFirst("iframe[src]")
            if (iframe != null) {
                val iframeUrl = iframe.attr("src")
                if (iframeUrl.contains("share4max") || iframeUrl.contains("megamax")) {
                    val videoUrl = extractMegamaxVideo(iframeUrl)
                    if (videoUrl != null) {
                        videoList.add(Video(videoUrl, "Megamax (Direct)", videoUrl))
                    }
                } else if (iframeUrl.contains("ok.ru")) {
                    videoList.add(Video(iframeUrl, "Okru", iframeUrl))
                } else if (iframeUrl.contains("dood")) {
                    videoList.add(Video(iframeUrl, "Dood", iframeUrl))
                }
            }
            return videoList
        }

        // Process each server tab
        for (tab in serverTabs) {
            val serverName = tab.text().trim()
            val frameserver = tab.attr("data-frameserver")
            val post = tab.attr("data-post")
            val serv = tab.attr("data-serv")

            if (frameserver.isBlank() || post.isBlank()) continue

            try {
                val ajaxUrl = "$baseUrl/wp-admin/admin-ajax.php"
                val formBody = FormBody.Builder()
                    .add("action", "codecanal_ajax_request")
                    .add("post", post)
                    .add("_server_code_", "")
                    .add("frameserver", frameserver)
                    .add("is_film", "")
                    .add("serv", serv.ifBlank { "_server_movie_$post" })
                    .build()

                val ajaxRequest = POST(ajaxUrl, headers, formBody)
                val ajaxResponse = client.newCall(ajaxRequest).execute()
                val ajaxBody = ajaxResponse.body?.string() ?: ""

                // Parse iframe from response
                val iframeMatch = Regex("<iframe[^>]+src=[\"']([^\"']+)[\"']").find(ajaxBody)
                if (iframeMatch != null) {
                    val iframeUrl = iframeMatch.groupValues[1]
                    val video = processServerVideo(iframeUrl, serverName)
                    if (video != null) {
                        videoList.add(video)
                    }
                }
            } catch (e: Exception) {
                Log.e("${name.lowercase()}-server", "Error loading $serverName: ${e.message}")
            }
        }

        return videoList
    }

    private fun processServerVideo(iframeUrl: String, serverName: String): Video? {
        return when {
            iframeUrl.contains("share4max") || iframeUrl.contains("megamax") -> {
                val videoUrl = extractMegamaxVideo(iframeUrl)
                videoUrl?.let { Video(it, "$serverName (MegaMax)", it) }
            }
            iframeUrl.contains("ok.ru") -> {
                Video(iframeUrl, "$serverName (Okru)", iframeUrl)
            }
            iframeUrl.contains("dood") -> {
                Video(iframeUrl, "$serverName (Dood)", iframeUrl)
            }
            else -> {
                // Generic iframe - return the iframe URL as video URL
                // The player will handle it
                Video(iframeUrl, serverName, iframeUrl)
            }
        }
    }

    private fun extractMegamaxVideo(iframeUrl: String): String? {
        // Try to fetch the iframe content to find the actual video source
        return try {
            val request = GET(iframeUrl, headers)
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""

            // Look for m3u8 or mp4 sources
            val m3u8Match = Regex("src=[\"']([^\"']+\\.m3u8[^\"']*)[\"']").find(body)
            if (m3u8Match != null) {
                return m3u8Match.groupValues[1]
            }

            val mp4Match = Regex("src=[\"']([^\"']+\\.mp4[^\"']*)[\"']").find(body)
            if (mp4Match != null) {
                return mp4Match.groupValues[1]
            }

            val sourceMatch = Regex("<source[^>]+src=[\"']([^\"']+)[\"']").find(body)
            if (sourceMatch != null) {
                return sourceMatch.groupValues[1]
            }

            // Look for video src in JS
            val jsMatch = Regex("""videoSrc\s*[:=]\s*["']([^"']+)["']""").find(body)
            if (jsMatch != null) {
                return jsMatch.groupValues[1]
            }

            // Look for file in jwplayer or similar
            val fileMatch = Regex("""file\s*[:=]\s*["']([^"']+)["']""").find(body)
            if (fileMatch != null) {
                return fileMatch.groupValues[1]
            }

            // Return iframe URL as fallback
            iframeUrl
        } catch (e: Exception) {
            Log.e("${name.lowercase()}-megamax", "Error extracting video: ${e.message}")
            iframeUrl
        }
    }

    override fun videoListRequest(episode: SEpisode): Request {
        return GET(baseUrl + episode.url, headers)
    }

    override fun List<Video>.sort(): List<Video> {
        val quality = preferences.getString("preferred_quality", "MegaMax")!!
        return sortedWith(
            compareBy { it.quality.contains(quality) }
        ).reversed()
    }

    // ============================== Filters ===============================

    override fun getFilterList(): AnimeFilterList {
        return AnimeFilterList()
    }

    // ============================== Preferences ===============================

    override fun setupPreferenceScreen(screen: PreferenceScreen) {
        val videoQualityPref = ListPreference(screen.context).apply {
            key = "preferred_quality"
            title = "Preferred server"
            entries = arrayOf("MegaMax", "Okru", "Dood")
            entryValues = arrayOf("MegaMax", "Okru", "Dood")
            setDefaultValue("MegaMax")
            summary = "%s"

            setOnPreferenceChangeListener { _, newValue ->
                val selected = newValue as String
                val index = findIndexOfValue(selected)
                val entry = entries[index] as String
                preferences.edit().putString(key, entry).commit()
            }
        }

        screen.addPreference(videoQualityPref)
    }
}
