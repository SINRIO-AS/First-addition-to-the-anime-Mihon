# Shahiid Anime Extension for Aniyomi

An Aniyomi extension for [Shahiid Anime](https://shahiid-anime.net), an Arabic anime streaming website.

## Extension Information

| Field | Value |
|-------|-------|
| **Name** | Shahiid Anime |
| **Language** | Arabic (ar) |
| **Base URL** | https://shahiid-anime.net |
| **Version** | 13.1 |

## Features

- Browse popular anime series
- View latest added episodes
- Search anime by name
- Multiple video servers (MegaMax, Okru, Dood, Leech)
- Configurable preferred server

## File Structure

```
src/ar/shahiidanime/
├── AndroidManifest.xml
├── build.gradle
├── README.md
└── src
    └── eu
        └── kanade
            └── tachiyomi
                └── animeextension
                    └── ar
                        └── shahiidanime
                            └── ShahiidAnime.kt
```

## Building Locally

### Prerequisites

- Android Studio or IntelliJ IDEA with Kotlin plugin
- JDK 11 or higher
- Android SDK

### Steps

1. **Clone the Aniyomi Extensions Repository**

   This extension is designed to be built within the Aniyomi extensions-source repository structure.

   ```bash
   # Clone the main extensions repository
   git clone https://github.com/aniyomiorg/aniyomi-extensions.git
   cd aniyomi-extensions
   ```

2. **Copy the Extension Files**

   Copy this extension folder to the repository:

   ```bash
   cp -r /path/to/this/extension src/ar/shahiidanime
   ```

3. **Configure settings.gradle.kts** (if needed)

   Make sure `src:ar:shahiidanime` is included. You may want to edit `settings.gradle.kts` to only load this extension:

   ```kotlin
   fun loadIndividualExtension(name: String) {
       // ...
   }

   // Load only this extension
   loadIndividualExtension("src:ar:shahiidanime")
   ```

4. **Build the Extension**

   ```bash
   ./gradlew src:ar:shahiidanime:assembleDebug
   ```

   For release build:
   ```bash
   ./gradlew src:ar:shahiidanime:assembleRelease
   ```

5. **Find the APK**

   The built APK will be at:
   - Debug: `src/ar/shahiidanime/build/outputs/apk/debug/shahiidanime-ar-shahiidanime-debug.apk`
   - Release: `src/ar/shahiidanime/build/outputs/apk/release/shahiidanime-ar-shahiidanime-release-unsigned.apk`

## Installing on Android

### Method 1: Install APK Directly

1. Transfer the built APK to your Android device
2. Open the APK file on your device
3. Allow installation from unknown sources if prompted
4. The extension should appear in Aniyomi's extension list

### Method 2: Through Aniyomi

1. Open Aniyomi app
2. Go to **Browse** → **Anime Extensions**
3. Tap the **+** button or **Install from file**
4. Select the built APK file

### Method 3: Add Repository URL

If you host this extension in a repository:

1. Open Aniyomi app
2. Go to **More** → **Settings** → **Browse** → **Anime Extension repos**
3. Add your repository URL
4. Find "Shahiid Anime" in the list and install it

## Testing the Extension

After installation:

1. Open Aniyomi app
2. Go to **Browse** → **Anime Sources**
3. Find and tap on **Shahiid Anime (AR)**
4. Browse the popular anime list or use search
5. Tap on an anime to view details
6. Select an episode to watch

### Testing Checklist

- [ ] **Popular Anime List** - Shows anime series from `/series/`
- [ ] **Latest Episodes** - Shows recently added episodes from `/episodes/`
- [ ] **Search** - Can search for anime by name
- [ ] **Anime Details** - Shows title, description, thumbnail, genre, status
- [ ] **Episode List** - Lists all episodes for a season
- [ ] **Video Playback** - Streams video from selected server
- [ ] **Server Selection** - Can choose between MegaMax, Okru, Dood servers

### Setting Preferred Server

1. In Aniyomi, go to **Browse** → **Anime Sources**
2. Find **Shahiid Anime (AR)** and tap the **⚙️ (Settings)** icon
3. Select your preferred server:
   - **MegaMax** - Primary server (usually fastest)
   - **Okru** - Ok.ru video hosting
   - **Dood** - Dood.to video hosting

## Troubleshooting

### Build Errors

If you encounter build errors:

1. Make sure you have the correct JDK version (11+)
2. Sync Gradle files in Android Studio
3. Check that the `common.gradle` file exists in the root directory
4. Ensure all dependencies are available

### Video Playback Issues

| Problem | Solution |
|---------|----------|
| Video won't load | Try a different server in settings |
| Slow buffering | Switch to Okru or Dood server |
| Empty episode list | The anime may have no episodes yet |
| MegaMax shows black screen | MegaMax uses WebView - ensure WebView is updated |

### Known Limitations

- **MegaMax Server**: Uses a JavaScript-based video player that requires WebView playback. The extension returns the iframe URL and relies on Aniyomi's internal player to handle it.
- **Cloudflare/Security Check**: If the website implements Cloudflare protection, the extension may not work until the security check passes
- **Server Down**: If one video server is down, try another from the settings
- **Geo-Blocking**: Some servers may block certain regions
- **Direct Video URLs**: The extension attempts to extract direct video URLs from servers when possible, but falls back to iframe URLs for JavaScript-based players

## Development Notes

### Website Structure

The extension scrapes the following pages:

| Page | URL Pattern | Purpose |
|------|------------|---------|
| Series List | `/series/page/{page}/` | Popular anime |
| Episodes List | `/episodes/page/{page}/` | Latest episodes |
| Search | `/?s={query}&paged={page}` | Search results |
| Anime Details | `/series/{slug}/` | Redirects to seasons page |
| Season Page | `/seasons/{slug}/` | Anime info + episode list |
| Episode Page | `/episodes/{slug}/` | Episode info + video servers |

### Video Extraction

Video servers are loaded via AJAX:
- **Endpoint**: `POST /wp-admin/admin-ajax.php`
- **Action**: `codecanal_ajax_request`
- **Parameters**: `post`, `frameserver`, `serv`, `_server_code_`, `is_film`

### Supported Servers

| Server | Pattern | Notes |
|--------|---------|-------|
| MegaMax | `share4max.com/iframe/{id}` | Uses JS player (WebView) |
| Okru | `ok.ru/videoembed/{id}` | Russian video host |
| Dood | `dood.to/e/{id}` | Alternative host |
| Leech | `share4max.com/iframe/{id}` | Mirror of MegaMax |

## Contributing

To contribute to this extension:

1. Fork the repository
2. Make your changes
3. Increment `extVersionCode` in `build.gradle`
4. Test the changes locally
5. Submit a pull request

## License

This extension is provided as-is for educational purposes. Please respect the content provider's terms of service.

## Disclaimer

This extension is not affiliated with Shahiid Anime. All content is provided by the respective website. Use at your own discretion.
