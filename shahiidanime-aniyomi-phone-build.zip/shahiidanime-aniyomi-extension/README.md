# Shahiid Anime Aniyomi extension

This is an Aniyomi/Anikku anime extension for https://shahiid-anime.net.

Package:

```text
eu.kanade.tachiyomi.animeextension.ar.shahiidanime
```

Build command inside `yuzono/anime-extensions`:

```bash
./gradlew src:ar:shahiidanime:assembleDebug
```

Phone build flow:

1. Upload `shahiidanime-aniyomi-phone-build.zip` to the root of your GitHub repository.
2. Replace `.github/workflows/build.yml` with the workflow in `.github/workflows/build-aniyomi.yml`.
3. Run the workflow from the GitHub Actions tab.
4. Download the artifact `shahiidanime-aniyomi-debug-apk` and install the APK in Aniyomi.

Notes:

- This extension uses public pages from the website.
- It does not bypass login, paywalls, DRM, CAPTCHA, or access controls.
- If a mirror uses unsupported dynamic JavaScript or protected video URLs, that mirror may be skipped.
