package eu.kanade.tachiyomi.animeextension.ar.shahiidanime

import android.util.Base64
import aniyomi.lib.doodextractor.DoodExtractor
import aniyomi.lib.megamaxmultiserver.MegaMaxMultiServer
import aniyomi.lib.okruextractor.OkruExtractor
import aniyomi.lib.universalextractor.UniversalExtractor
import eu.kanade.tachiyomi.animesource.model.AnimeFilterList
import eu.kanade.tachiyomi.animesource.model.AnimesPage
import eu.kanade.tachiyomi.animesource.model.SAnime
import eu.kanade.tachiyomi.animesource.model.SEpisode
import eu.kanade.tachiyomi.animesource.model.Video
import eu.kanade.tachiyomi.animesource.online.AnimeHttpSource
import eu.kanade.tachiyomi.network.GET
import keiyoushi.utils.parallelCatchingFlatMapBlocking
import keiyoushi.utils.useAsJsoup
import okhttp3.Headers
import okhttp3.Request
import okhttp3.Response
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Locale

class ShahiidAnime : AnimeHttpSource() {

    override val name = "Shahiid Anime"

    override val baseUrl = "https://shahiid-anime.net"

    override val lang = "ar"

    override val supportsLatest = true

    override fun headersBuilder() = super.headersBuilder()
        .add("Accept-Language", "ar,en-US;q=0.8,en;q=0.5")
        .add("Referer", "$baseUrl/")

    override fun popularAnimeRequest(page: Int): Request =
        GET(archiveUrl("series", page), headers)

    override fun popularAnimeParse(response: Response): AnimesPage =
        parseCatalog(response.useAsJsoup(), listOf("/series/"), "series")

    override fun latestUpdatesRequest(page: Int): Request =
        GET(archiveUrl("episodes", page), headers)

    override fun latestUpdatesParse(response: Response): AnimesPage =
        parseCatalog(response.useAsJsoup(), listOf("/episodes/"), "episodes")

    override fun searchAnimeRequest(page: Int, query: String, filters: AnimeFilterList): Request {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val pageParam = if (page > 1) "&paged=$page" else ""
        return GET("$baseUrl/?s=$encoded$pageParam", headers)
    }

    override fun searchAnimeParse(response: Response): AnimesPage =
        parseCatalog(
            response.useAsJsoup(),
            listOf("/series/", "/seasons/", "/episodes/"),
            null,
        )

    override fun animeDetailsParse(response: Response): SAnime {
        val document = response.useAsJsoup()
        val bodyText = document.body()?.text().orEmpty()
        val description = extractDescription(bodyText)

        return SAnime.create().apply {
            title = document.selectFirst("h1")?.text()?.let(::cleanTitle).orEmpty()
            thumbnail_url = document.metaImage() ?: document.firstUsableImage()
            genre = extractGenres(bodyText).joinToString()
            author = extractLabel(bodyText, "الاستوديو:", listOf("الجودة", "الفئة العمرية", "السنة", "النوع", "رقم"))
            artist = extractLabel(bodyText, "الدولة :", listOf("اللغة", "حالة", "مدة", "تقييم"))
            status = parseStatus(bodyText)
            this.description = description
        }
    }

    override fun episodeListParse(response: Response): List<SEpisode> {
        val document = response.useAsJsoup()
        val episodes = linkedMapOf<String, SEpisode>()

        document.select("a[href*='/episodes/']").forEach { anchor ->
            val href = anchor.absUrl("href")
            if (href.isBlank()) return@forEach

            val relative = href.toRelativeUrl()
            if (isNavigationUrl(relative)) return@forEach

            val nameFromText = cleanTitle(
                anchor.text()
                    .ifBlank { anchor.attr("title") }
                    .ifBlank { anchor.selectFirst("img")?.attr("alt").orEmpty() },
            )
            val nameFromUrl = episodeTitleFromUrl(relative)
            val name = bestEpisodeTitle(nameFromText, nameFromUrl)
            if (name.isBlank() || looksLikeNavigationTitle(name)) return@forEach

            val episode = SEpisode.create().apply {
                this.name = name
                setUrlWithoutDomain(href)
                episode_number = parseEpisodeNumber(name).takeIf { it >= 0F }
                    ?: parseEpisodeNumber(nameFromUrl)
            }

            val existing = episodes[relative]
            if (existing == null || titleScore(episode.name) > titleScore(existing.name)) {
                episodes[relative] = episode
            }
        }

        if (episodes.isEmpty() && document.location().contains("/episodes/")) {
            val requestUrl = response.request.url.toString()
            val episodeTitle = document.selectFirst("h1")?.text()?.let(::cleanTitle)
                ?: episodeTitleFromUrl(requestUrl.toRelativeUrl())
            episodes[requestUrl.toRelativeUrl()] = SEpisode.create().apply {
                name = episodeTitle
                setUrlWithoutDomain(requestUrl)
                episode_number = parseEpisodeNumber(episodeTitle)
            }
        }

        return episodes.values
            .sortedWith(
                compareByDescending<SEpisode> { episode ->
                    episode.episode_number.takeIf { it >= 0F } ?: -1F
                }.thenByDescending { it.url },
            )
    }

    override fun videoListParse(response: Response): List<Video> {
        val document = response.useAsJsoup()
        val referer = response.request.url.toString()
        val serverUrls = extractVideoServerUrls(document)

        return serverUrls
            .parallelCatchingFlatMapBlocking { extractVideos(it, referer) }
            .distinctBy { it.videoUrl }
    }

    override fun videoListRequest(episode: SEpisode): Request =
        GET("$baseUrl${episode.url}", headers)

    override fun getFilterList(): AnimeFilterList = AnimeFilterList()

    override fun List<Video>.sort(): List<Video> =
        sortedWith(
            compareByDescending<Video> { qualityValue(it.quality) }
                .thenBy { it.quality },
        )

    private val doodExtractor by lazy { DoodExtractor(client) }
    private val okruExtractor by lazy { OkruExtractor(client, headers) }
    private val megaMaxMultiServer by lazy { MegaMaxMultiServer(client, headers) }
    private val universalExtractor by lazy { UniversalExtractor(client) }

    private suspend fun extractVideos(url: String, episodeReferer: String): List<Video> {
        val fixedUrl = fixUrl(decodeIfBase64(url)) ?: return emptyList()
        val lowerUrl = fixedUrl.lowercase(Locale.ROOT)
        val streamHeaders = headers.newBuilder()
            .set("Referer", episodeReferer)
            .build()

        return runCatching {
            when {
                lowerUrl.contains("megamax") -> megaMaxMultiServer.extractUrls(fixedUrl).map { provider ->
                    val quality = listOf("Megamax", provider.name, provider.quality, provider.size)
                        .filter { it.isNotBlank() }
                        .joinToString(" - ")
                    Video(provider.url, quality, provider.url, streamHeaders)
                }

                lowerUrl.contains("ok.ru") || lowerUrl.contains("okru") -> okruExtractor.videosFromUrl(fixedUrl)

                lowerUrl.contains("dood") -> doodExtractor.videoFromUrl(fixedUrl, "Dood")
                    ?.let(::listOf)
                    ?: emptyList()

                directVideoRegex.containsMatchIn(lowerUrl) -> listOf(
                    Video(
                        fixedUrl,
                        directQuality(fixedUrl),
                        fixedUrl,
                        streamHeaders,
                    ),
                )

                else -> universalExtractor.videosFromUrl(
                    fixedUrl,
                    streamHeaders,
                    prefix = serverLabel(fixedUrl),
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun extractVideoServerUrls(document: Document): List<String> {
        val urls = linkedSetOf<String>()

        document.select(
            "iframe[src], video[src], source[src], " +
                "a[href], a[data-url], a[data-src], a[data-link], " +
                "button[data-url], button[data-src], button[onclick], " +
                "li[data-url], li[data-src], li[onclick], " +
                "[data-embed], [data-iframe], [data-player]",
        ).forEach { element ->
            listOf(
                "data-url",
                "data-src",
                "data-link",
                "data-embed",
                "data-iframe",
                "data-player",
                "src",
                "href",
                "onclick",
            ).forEach { attrName ->
                addPotentialUrl(element.attr(attrName), urls)
            }
        }

        pageUrlRegex.findAll(document.html()).forEach { match ->
            addPotentialUrl(match.value.replace("\\/", "/"), urls)
        }

        return urls
            .mapNotNull { fixUrl(decodeIfBase64(it)) }
            .filter(::isVideoHostUrl)
            .distinct()
    }

    private fun addPotentialUrl(rawValue: String, urls: MutableSet<String>) {
        if (rawValue.isBlank()) return

        val decoded = decodeIfBase64(rawValue)
        fixUrl(decoded)?.let(urls::add)

        pageUrlRegex.findAll(rawValue).forEach { match ->
            fixUrl(match.value.replace("\\/", "/"))?.let(urls::add)
        }
    }

    private fun isVideoHostUrl(url: String): Boolean {
        val normalized = url.lowercase(Locale.ROOT)
        if (normalized.contains("shahiid-anime.net") && !normalized.contains("player")) return false
        return videoHostKeywords.any { normalized.contains(it) } || directVideoRegex.containsMatchIn(normalized)
    }

    private fun archiveUrl(path: String, page: Int): String =
        if (page <= 1) "$baseUrl/$path/" else "$baseUrl/$path/page/$page/"

    private fun parseCatalog(document: Document, allowedSegments: List<String>, archivePath: String?): AnimesPage {
        val entries = linkedMapOf<String, SAnime>()

        document.select("a[href]").forEach { anchor ->
            val href = anchor.absUrl("href")
            if (href.isBlank()) return@forEach

            val relative = href.toRelativeUrl()
            if (allowedSegments.none { relative.contains(it) }) return@forEach
            if (isNavigationUrl(relative)) return@forEach

            val rawTitle = anchor.text()
                .ifBlank { anchor.attr("title") }
                .ifBlank { anchor.selectFirst("img")?.attr("alt").orEmpty() }
            val title = cleanTitle(rawTitle.ifBlank { titleFromUrl(relative) })
            if (title.isBlank() || looksLikeNavigationTitle(title)) return@forEach

            val anime = SAnime.create().apply {
                this.title = title
                setUrlWithoutDomain(href)
                thumbnail_url = findNearbyImage(anchor)
            }

            val existing = entries[relative]
            if (existing == null || titleScore(anime.title) > titleScore(existing.title)) {
                entries[relative] = anime
            }
        }

        return AnimesPage(entries.values.toList(), hasNextPage(document, archivePath))
    }

    private fun hasNextPage(document: Document, archivePath: String?): Boolean {
        if (document.select("a[rel=next]").isNotEmpty()) return true

        return document.select("a[href]").any { anchor ->
            val href = anchor.absUrl("href")
            val text = anchor.text()
            val pointsToNextArchive = archivePath == null || href.contains("/$archivePath/page/") || href.contains("paged=")
            pointsToNextArchive && (text == "›" || text == "»" || text.equals("next", ignoreCase = true))
        }
    }

    private fun Document.metaImage(): String? = selectFirst("meta[property=og:image], meta[name=twitter:image]")
        ?.imageUrl()
        ?.takeIf(::isUsableImage)

    private fun Document.firstUsableImage(): String? = select("img")
        .asSequence()
        .mapNotNull { it.imageUrl() }
        .firstOrNull(::isUsableImage)

    private fun findNearbyImage(element: Element): String? =
        (sequenceOf(element) + element.parents().asSequence().take(3))
            .flatMap { it.select("img").asSequence() }
            .mapNotNull { it.imageUrl() }
            .firstOrNull(::isUsableImage)

    private fun Element.imageUrl(): String? {
        val attrs = when (tagName().lowercase(Locale.ROOT)) {
            "meta" -> listOf("content")
            else -> listOf("data-src", "data-lazy-src", "data-original", "src")
        }

        attrs.forEach { attrName ->
            val raw = attr(attrName).trim()
            if (raw.isBlank() || raw.startsWith("data:")) return@forEach
            if (raw.startsWith("//")) return "https:$raw"
            if (raw.startsWith("http://") || raw.startsWith("https://")) return raw

            val absolute = absUrl(attrName)
            if (absolute.isNotBlank()) return absolute
            return "$baseUrl/${raw.removePrefix("/")}"
        }

        return null
    }

    private fun String.toRelativeUrl(): String = replace(Regex("^https?://(www\\.)?shahiid-anime\\.net"), "")
        .ifBlank { "/" }

    private fun isNavigationUrl(relativeUrl: String): Boolean =
        relativeUrl == "/" ||
            relativeUrl == "/series/" ||
            relativeUrl == "/episodes/" ||
            relativeUrl.contains("/page/") ||
            relativeUrl.contains("#") ||
            relativeUrl.contains("?download=") ||
            relativeUrl.contains("/privacy") ||
            relativeUrl.contains("/dmca")

    private fun looksLikeNavigationTitle(title: String): Boolean {
        val normalized = title.trim().lowercase(Locale.ROOT)
        if (normalized.isBlank()) return true
        if (normalized.matches(Regex("^[0-9.]+$"))) return true
        if (normalized in navigationTitles) return true
        return normalized.length <= 1
    }

    private fun cleanTitle(rawTitle: String): String {
        var title = rawTitle
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()

        title = title.replace(Regex("^(TV|ONA|OVA|Movie|Web|Bluray|BD|FHD|HD|مدبلج)\\s+", RegexOption.IGNORE_CASE), "")
        title = title.replace(Regex("^\\d(?:\\.\\d{1,2})?\\s+"), "")

        return title.trim(' ', '-', '–', '|')
    }

    private fun titleFromUrl(relativeUrl: String): String = decodeUrl(relativeUrl)
        .trim('/')
        .substringAfterLast('/')
        .replace('-', ' ')
        .let(::cleanTitle)

    private fun episodeTitleFromUrl(relativeUrl: String): String = titleFromUrl(relativeUrl)

    private fun bestEpisodeTitle(textTitle: String, urlTitle: String): String = when {
        urlTitle.contains("الحلقة") && !textTitle.contains("الحلقة") -> urlTitle
        parseEpisodeNumber(urlTitle) >= 0F && parseEpisodeNumber(textTitle) < 0F -> urlTitle
        titleScore(urlTitle) > titleScore(textTitle) + 20 -> urlTitle
        textTitle.isNotBlank() -> textTitle
        else -> urlTitle
    }

    private fun titleScore(title: String): Int = title.length + if (title.contains("الحلقة")) 30 else 0

    private fun parseEpisodeNumber(name: String): Float {
        val patterns = listOf(
            Regex("الحلقة\\s*(?:الخاصة\\s*)?(\\d+(?:\\.\\d+)?)"),
            Regex("episode\\s*(\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE),
            Regex("ep[-_\\s]*(\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE),
        )

        return patterns.firstNotNullOfOrNull { regex ->
            regex.find(name)?.groupValues?.getOrNull(1)?.toFloatOrNull()
        } ?: -1F
    }

    private fun parseStatus(text: String): Int = when {
        text.contains("يعرض حاليا") || text.contains("مستمر") || text.contains("أنميات المستمرة") -> SAnime.ONGOING
        text.contains("مكتمل") || text.contains("منتهي") || text.contains("الأخيرة") -> SAnime.COMPLETED
        else -> SAnime.UNKNOWN
    }

    private fun extractDescription(text: String): String {
        val startMarkers = listOf("قصة الأنيمي :", "قصة الأنيمي:", "قصة هذا الموسم:", "قصة الحلقة :", "قصة الحلقة:")
        val endMarkers = listOf("الاستوديو:", "الجودة :", "الجودة:", "الفئة العمرية", "السنة :", "النوع :", "رقم المسلسل", "رقم الموسم", "رقم الحلقة", "الرابط المختصر")

        val start = startMarkers
            .map { text.indexOf(it) }
            .filter { it >= 0 }
            .minOrNull()
            ?: return ""

        val afterStart = startMarkers.firstOrNull { text.indexOf(it) == start }
            ?.let { start + it.length }
            ?: start

        val end = endMarkers
            .map { text.indexOf(it, afterStart) }
            .filter { it > afterStart }
            .minOrNull()
            ?: text.length

        return text.substring(afterStart, end)
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun extractLabel(text: String, startMarker: String, endMarkers: List<String>): String? {
        val start = text.indexOf(startMarker)
        if (start < 0) return null
        val afterStart = start + startMarker.length
        val end = endMarkers
            .map { text.indexOf(it, afterStart) }
            .filter { it > afterStart }
            .minOrNull()
            ?: text.length

        return text.substring(afterStart, end)
            .replace(Regex("\\s+"), " ")
            .trim(' ', ':', '،', ',')
            .takeIf { it.isNotBlank() }
    }

    private fun extractGenres(text: String): List<String> = knownGenres.filter { genre ->
        Regex("(^|\\s|،|,)$genre(\\s|،|,|$)").containsMatchIn(text)
    }

    private fun isUsableImage(url: String): Boolean {
        val normalized = url.lowercase(Locale.ROOT)
        if (normalized.isBlank()) return false
        if ("shahiid-anime" in normalized && ("logo" in normalized || "220px" in normalized)) return false
        return normalized.startsWith("http://") || normalized.startsWith("https://")
    }

    private fun decodeIfBase64(value: String): String {
        val trimmed = value.trim().trim('"', '\'', ' ')
        if (trimmed.startsWith("http") || trimmed.startsWith("//") || trimmed.startsWith("/")) return trimmed
        if (!trimmed.matches(base64Regex)) return trimmed

        return runCatching {
            String(Base64.decode(trimmed, Base64.DEFAULT)).trim()
        }.getOrDefault(trimmed)
    }

    private fun decodeUrl(value: String): String = runCatching {
        URLDecoder.decode(value, "UTF-8")
    }.getOrDefault(value)

    private fun fixUrl(rawUrl: String): String? {
        val cleaned = decodeUrl(rawUrl)
            .trim()
            .trim('"', '\'', ' ', ';')
            .replace("\\/", "/")

        if (cleaned.isBlank()) return null
        if (cleaned.startsWith("javascript:", ignoreCase = true)) return null
        if (cleaned.startsWith("data:", ignoreCase = true)) return null
        if (cleaned.startsWith("//")) return "https:$cleaned"
        if (cleaned.startsWith("http://") || cleaned.startsWith("https://")) return cleaned
        if (cleaned.startsWith("/")) return "$baseUrl$cleaned"
        return null
    }

    private fun directQuality(url: String): String = when {
        url.contains(".m3u8", ignoreCase = true) -> "Direct HLS"
        url.contains(".mpd", ignoreCase = true) -> "Direct DASH"
        else -> "Direct MP4"
    }

    private fun serverLabel(url: String): String {
        val host = Regex("https?://([^/]+)").find(url)?.groupValues?.getOrNull(1).orEmpty()
        return host.substringBeforeLast('.').substringAfterLast('.').replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
        }.ifBlank { "Mirror" }
    }

    private fun qualityValue(quality: String): Int = Regex("(\\d{3,4})p")
        .find(quality)
        ?.groupValues
        ?.getOrNull(1)
        ?.toIntOrNull()
        ?: 0

    companion object {
        private val base64Regex = Regex("^[A-Za-z0-9+/=_-]{16,}$")
        private val pageUrlRegex = Regex("https?:\\\\?/\\\\?/[^\\s'\"<>]+|https?://[^\\s'\"<>]+")
        private val directVideoRegex = Regex("\\.(mp4|m3u8|mpd)(\\?|$)", RegexOption.IGNORE_CASE)

        private val videoHostKeywords = listOf(
            "megamax",
            "ok.ru",
            "okru",
            "dood",
            "videa",
            "vidbom",
            "vidbam",
            "leech",
            "iframe",
            "embed",
            "player",
        )

        private val navigationTitles = setOf(
            "الرئيسية",
            "قائمة الأنمي",
            "تصفح المزيد",
            "تصفح المزيد ...",
            "تحميل الحلقة",
            "مشاهدة الحلقة",
            "تبليغ",
            "privacy",
            "dmca",
        )

        private val knownGenres = listOf(
            "أساطير",
            "أطفال",
            "أكشن",
            "أيدول",
            "إيسكاي",
            "اتشي",
            "الاثارة",
            "التاريخية",
            "الجيش",
            "الرياضة",
            "الساموراي",
            "الشرطة",
            "الفضاء",
            "القصة المثيرة",
            "المغامرة",
            "النفسي",
            "ايتشي",
            "بقاء",
            "تاريخي",
            "تاريخية",
            "تحقيق",
            "تشويق",
            "جريمة",
            "جوسي",
            "حب بنات",
            "حركة",
            "حريم",
            "حياة عملية",
            "خارق",
            "خارق للطبيعة",
            "خيال",
            "خيال علمي",
            "دراما",
            "ذواقة",
            "رعب",
            "رومانسي",
            "رياضة",
            "رياضي",
            "ساخر",
            "ساموراي",
            "سباق",
            "سحر",
            "سنين",
            "سوجو",
            "سينين",
            "شريحة من الحياة",
            "شوتينغ",
            "شوجو",
            "شونين",
            "شياطين",
            "شيطان",
            "عاطفي",
            "عسكري",
            "علمي",
            "عنف دموي",
            "غموض",
            "فانتازيا",
            "فضاء",
            "فنون الدفاع عن النفس",
            "فنون القتال",
            "قوة",
            "قوة عظمى",
            "قوى خارقة",
            "كوميديا",
            "لعبة",
            "مدبلج",
            "مدرسي",
            "مشاغبون",
            "مصاص الدماء",
            "مغامرات",
            "موسيقى",
            "ميكا",
            "نفسي",
        )
    }
}
